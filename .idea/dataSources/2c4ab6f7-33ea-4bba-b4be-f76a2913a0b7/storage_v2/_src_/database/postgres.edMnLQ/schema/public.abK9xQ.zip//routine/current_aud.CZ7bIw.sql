create function current_aud() returns text
    language sql
as
$$
select coalesce(
               (current_setting('request.jwt.claims', true)::json ->> 'aud'),
               'unknown'
       );
$$;

alter function current_aud() owner to postgres;

grant execute on function current_aud() to anon;

grant execute on function current_aud() to authenticated;

grant execute on function current_aud() to service_role;

